# -*- coding: utf-8 -*-
"""
Created on Fri Jul 08 13:06:26 2016

@author: hang.li
"""

import sys
# Always put this on the top of your code
sys.path.append('/home/ec2-user/anaconda2/lib/python2.7/site-packages')

import pandas as pd
import zipfile
import time
import os
#import csv
#import glob
import psycopg2





def download_from_FTP(ftp_host,ftp_username,ftp_password,ftp_dir,local_path,ftp_fileformat):
    from ftplib import FTP
    print '\n' + "=============================================================================================" + '\n'
    print "Start downloading CSV from FTP"
    try:
        ftp = FTP(ftp_host)
        ftp.login(user=ftp_username, passwd = ftp_password)
        print '\n'+'Successfully connect to the FTP'

    except Exception as e:
        print '\n'+'Had error connecting to the FTP'
        logging.warning(e)

    #ftp.retrlines('LIST')     # list directory contents 
    ftp.cwd(ftp_dir)

    filenames = ftp.nlst()
    i=0   
    filenames_filtered =[]
    # Download files from FTP folder to local Temp and Archive
    for filename in filenames:
        i = i + 1    
        if ftp_fileformat in filename:
            filenames_filtered.append(filename)
            local_filename = os.path.join(local_path, filename)
            file_Temp = open(local_filename, 'wb')
            ftp.retrbinary('RETR '+ filename, file_Temp.write)
            file_Temp.close()      
    print '\n' + '========Successfully download ',i,' files into local Temp folder  C:\Users\hang.li\Documents\Python Scripts========='
    return filenames_filtered
    
    
def getName_from_path(path):
#Get filename from a s3 object key    
    if "/" in path:
        return path.rsplit("/")[1]
    else:
        return path
    
    
#s3 = boto3.resource('s3')
def download_S3(s3_bucket,s3_path,filename):
#Download S3 files to C:\Users\hang.li\Documents\Python Scripts
    #filename = 'FB All Data - All Accounts - Demographic - 360i - 110915 - 2016-06-30.zip'
    print '\n' + "=============================================================================================" + '\n'
    print "Start downloading files from S3"    

    s3_resource = boto3.resource('s3') 
    s3 = s3_resource.meta.client
    
    for obj in s3_resource.Bucket(s3_bucket).objects.filter(Prefix = s3_path, Delimiter = "/"):  
        s3.download_file(s3_bucket, obj.key, '/FB')


def unzip2CSV(filename):
    print '\n' + '=============================================================================================='+ '\n'
    print "Start upzip file %s"%filename    
    
    try:    
        f = zipfile.ZipFile(filename, 'r')
        i = 0
        for n in f.namelist():
            f.extract(n)
            i=i+1
            print "Successfully unzipped %s files, %s"%(i,n)
        
        f.close()
        #data = pd.read_csv('reports/FB All Data - All Accounts - Demographic - 360i - 110915-0.csv')
        return f.namelist()
        
    except Exception as e:
        print '\n' + 'Had error unzip files'
        logging.warning(e)
#list(data.columns.values)

def get_creation_time(filename):
    from datetime import datetime
    t = datetime.strptime(time.ctime(os.path.getctime(filename)), "%a %b %d %H:%M:%S %Y").date()
    return t.strftime("%Y-%m-%d")
    
def transform_target_facebook(data_csv):
#Group Facebook Data by date, campaignName and Placement(device)
    creation_time = get_creation_time(data_csv)    
    data_csv = pd.read_csv(data_csv) #read data from a string type parameter    
    grouped_data = data_csv.groupby(['Date Start', 'Campaign Name', 'Campaign ID', 'Placement'], as_index = False)[['Impressions', 'Spend', 'Clicks']].sum()
    grouped_data['VideoViews'] = 0
    grouped_data['Engagement'] = 0
    grouped_data.rename(columns = {'Date Start':'DateStart', 'Campaign Name':'CampaignName', 'Campaign ID':'CampaignID'}, inplace = True)
    grouped_data.describe()
            
    grouped_data.to_csv('FacebookDataFeed_transformed_'+creation_time + '.csv', sep = '|', index = False)
    filename_archive = 'FacebookDataFeed_transformed_'+creation_time + '.csv'    
    return filename_archive
#shutil.rmtree(r'C:\Users\hang.li\Documents\Python Scripts\reports')

def upload2S3(filename,local_path,s3_bucket,s3_path):
    #filenames = ''FacebookDataFeed_transformed'
    #Upload onto S3	
    print '\n' + "=============================================================================================" + '\n'
    print "Start uploading CSV into S3"

    s3 = boto3.client('s3')
    
    
    #filename_archive = filenames + get_creation_time(filenames) + '.csv'  #Filename is just name without file extension
    
    if type(filename) == str:         # single file from webpage
        local_path_filename = os.path.join(local_path, filename)
        try:	
            s3.upload_file(local_path_filename, "%s" % s3_bucket,  "%s/%s"  % (s3_path,filename))
            

            # Delete file in local
            os.remove(local_path_filename)
            print '\n' + 'Successfully upload 1 file into S3'
            
            s3_fullpath = "s3://%s/%s/%s"%(s3_bucket ,s3_path, filename)
            return s3_fullpath
        except Exception as e:	
            print '\n'+'Had error uploading data to S3'
            logging.warning(e)


def conn_to_rs(rs_host, rs_dbname, rs_port, rs_user, rs_password):
    #Load file from S3 to Redshift
    print '\n' + '=====================================================================================' + '\n'
    print """Start connecting to %s/%s:%s as %s"""%(rs_host, rs_dbname, rs_port, rs_user)
     
    try:
        con = psycopg2.connect(dbname = rs_dbname, host = rs_host,
                               port = rs_port, user = rs_user, password = rs_password )
        cur = con.cursor()
        cur.execute("select 1 from information_schema.tables;")
        print '\n' + "Successfully connected"
    except Exception as e:
        print '\n'+'Had errors connecting to the Redshift'
        logging.warning(e)
    return con
    
    
def close_rs_con(con, cur):    
    try:    
        cur.close()
        con.close()
    except Exception as e:
        logging.warning(e)
    print '\n' + 'Successfully closed connections.'



'''
from sqlalchemy import create_engine
import pandas as padas
engine = create_engine('postgresql://scott:tiger@hredshift_host:5439/mydatabase')
data_frame = padas.read_sql_query('SELECT * FROM `table`;', engine)
'''

#if __name__ == "__main__":
def lambda_handler(event, context):
    import logging    
    import sys
    import boto3
    
    # logging.basicConfig(filename='Errors.txt',stream=sys.stdout,level=logging.DEBUG)
    # orig_stdout = sys.stdout
    # logs = file('Logs'+'.txt', 'w')    
    # sys.stdout = logs

####################################################################################################################################
############################################################## Cutomize parameters below ###########################################
####################################################################################################################################
    local_path = '/tmp'
    
    s3_bucket = '360itarget'
    s3_folder = "Brandnetwork/facebook"
    s3_folder_archive = "Brandnetwork/facebook/Archive"
    s3_fileformat = 'FB All Data'
    
    
    rs_dbname = 'target'
    rs_host = 'sqldw.cpbjyyy6uuz2.us-east-1.redshift.amazonaws.com'
    rs_port = '5439'
    rs_user = 'sqldw_admin'
    rs_password = 'Welcome123'
    rs_stagetable =  'target_bn_facebook_stage'
    rs_actualtable = 'target_bn_facebook'
    
    ftp_user = '360i_target'
    ftp_password = 'nyEJHFJebAm5nAEN'
    ftp_host = 'ftp.360i.com'
    ftp_port = 22
    ftp_dir = '/AWS/'
    ftp_fileformat = 'FB All Data - All Accounts - Demographic - 360i - AWS'
    
####################################################################################################################################
############################################################## Cutomize parameters above ###########################################
####################################################################################################################################
   

    ls = download_from_FTP(ftp_host,ftp_user,ftp_password,ftp_dir,local_path,ftp_fileformat)
    s3_files = []    
    for filename in ls:
        data_csv = unzip2CSV(filename)      
        #In case zipped file contains a folder composed of multiple files        
        for a in data_csv:   # i.e. a = reports/FB All Data - All Accounts - Demographic - 360i - AWS -0.csv     
            filename_transformed = transform_target_facebook(a)
            s3_file = upload2S3(filename_transformed,local_path,s3_bucket,s3_folder) #upload transformed file
            s3_files.append(s3_file)            
            
        upload2S3(filename,local_path,s3_bucket,s3_folder_archive) #upload raw file        
     
    dest_con = conn_to_rs(rs_host, rs_dbname, rs_port, rs_user, rs_password)
    dest_cur = dest_con.cursor()

################################################### Update mergeing process below if needed #####################################################        


    for s3_file in s3_files:    
        #Truncate staging table        
        dest_cur.execute("Delete from target_bn_facebook_stage;")    
        #Copy S3 file to Redshift        
        dest_cur.execute("""
                copy %s from '%s' 
                credentials 'aws_access_key_id=AKIAJIA4UQSNQVWLZTQA;aws_secret_access_key=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' 
                dateformat 'auto' IGNOREHEADER 1  delimiter '|' region 'us-east-1';"""%(rs_stagetable, s3_file))
        #Merge from staging to actual table
        dest_cur.execute("""
                begin transaction;                
                delete from {actual}
                using {stage}
                where {actual}.DateStart = {stage}.DateStart
                and {actual}.CampaignName = {stage}.CampaignName
                and {actual}.placement = {stage}.placement;
                end transaction;""".format(actual=rs_actualtable,stage=rs_stagetable))
        dest_con.commit()
    dest_con.close()       
    
    